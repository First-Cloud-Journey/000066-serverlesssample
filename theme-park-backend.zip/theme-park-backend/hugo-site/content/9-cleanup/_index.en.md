+++
title = "Cleanup"
chapter = true
weight = 90
+++

Once you have finished with the workshop, delete the associated resources to prevent incurring ongoing charges in your AWS account.