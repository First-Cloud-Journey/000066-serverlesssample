+++
title = "Introduction"
chapter = true
weight = 1
+++

This section explains the scenario, the overall application structure, and the expected cost if you are running this workshop in your own AWS account.