+++
title = "Deploy the application"
chapter = true
weight = 11
pre = "<b>1. </b>"
+++

This section explains the backend and frontend structure. You'll deploy the frontend application, then the backend resources. Finally, you will connect the two and redeploy.