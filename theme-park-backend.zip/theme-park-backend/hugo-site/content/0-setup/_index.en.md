+++
title = "Setup"
chapter = true
weight = 2
+++

This section explains how to use or create an AWS account for the workshop, which AWS Regions you can use, and how to set up the AWS Cloud9 IDE used to complete the modules.