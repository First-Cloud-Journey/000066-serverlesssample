+++
title = "AWS Region"
weight = 12
+++

Use a single region for the entirety of this workshop. This workshop only supports the following regions:

- us-west-2 (US West - Oregon)
- us-east-2 (US East - Ohio)
- us-east-1 (US East - Northern Virginia)
- ap-northeast-1 (Asia Pacific - Tokyo)
- ap-southeast-2 (Sydney, Australia)
- eu-central-1 (Frankfurt, Germany)
- eu-west-1 (Dublin, Ireland)
- sa-east-1 (South America - São Paulo)