+++
title = "Bug/feature request"
chapter = true
weight = 92
+++

### Have an idea for this workshop? Found a bug? ###

If you have an idea for a module or feature in this workshop, or you have found a bug or need to report a problem, let us know!

{{% button href="https://github.com/aws-samples/aws-serverless-workshop-innovator-island/issues/new?assignees=&labels=&template=workshop-feature-request.md&title=" icon="fas fa-lightbulb" %}}Request a feature{{% /button %}}
{{% button href="https://github.com/aws-samples/aws-serverless-workshop-innovator-island/issues/new?assignees=&labels=&template=bug_report.md&title=" icon="fas fa-bug" %}}Report an issue{{% /button %}}




