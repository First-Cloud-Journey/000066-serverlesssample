+++
title = "Translation"
chapter = true
weight = 14
pre = "<b>4. </b>"
+++

The module shows how to use Amazon Translate to make your frontend application multilingual.