+++
title = "Overview"
weight = 11
+++

Many of the visitors to the the park's island come from all over the world and English is not their first language. Adding alternative language options will make it much easier for guests to understand and interact with the app.

