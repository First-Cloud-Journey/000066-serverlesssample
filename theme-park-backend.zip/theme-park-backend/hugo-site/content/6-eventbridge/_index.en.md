+++
title = "Event-based architecture"
chapter = true
weight = 18
pre = "<b>6. </b>"
+++

This module shows how to use event-based architectures to build new features without changing existing code. In this module, you are going to build new functionality that allows the park's maintenance teams to get alerts from the ride systems.
