+++
title = "On-ride photo processing"
chapter = true
weight = 13
pre = "<b>3. </b>"
+++

This module shows how to use a Lambda function to perform a chroma key operation on user-generated images. It explains how the work is processed asynchronously and shows how to alert the frontend when the image is ready.