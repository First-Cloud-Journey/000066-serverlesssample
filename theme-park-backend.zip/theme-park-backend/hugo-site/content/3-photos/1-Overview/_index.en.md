+++
title = "Overview"
weight = 11
+++

Park guests love taking photos on the rides and attractions. This app feature will let guests take a selfie and see a composited picture in the application. From here, they can publish their masterpiece on social media.

{{% notice info %}}
This module is also available to [watch on YouTube](https://www.youtube.com/watch?v=aNgmgZjzNr4).
{{% /notice %}}
