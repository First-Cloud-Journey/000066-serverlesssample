+++
title = "Overview"
weight = 11
+++

The theme park uses a proprietary system called the **Flow & Traffic Controller** to estimate wait times for rides. To help ease congestion, you will publish ride times directly into the application so guests can plan their day.

{{% notice info %}}
This module is also available to [watch on YouTube](https://www.youtube.com/watch?v=EhgOoFbCID0).
{{% /notice %}}
