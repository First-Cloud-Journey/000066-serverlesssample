+++
title = "Real-time ride wait times"
chapter = true
weight = 12
pre = "<b>2. </b>"
+++

This section shows how to connect a service with realtime data to a frontend application using a serverless approach. It explains how to connect a backend application with the ride times system and then use an IoT topic to communicate with the frontend.