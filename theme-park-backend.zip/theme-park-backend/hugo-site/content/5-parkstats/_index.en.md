+++
title = "Park stats"
chapter = true
weight = 16
pre = "<b>5. </b>"
+++

This module shows how to analyze streaming data using Amazon Kinesis, Lambda, and Amazon QuickSight. You will deploy a simulator to create the data, then ingest and analyze the data.