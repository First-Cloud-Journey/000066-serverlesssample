sh ./theme-park-backend/3-photos/1-chromakey/module3-1-script.sh 
sh ./theme-park-backend/3-photos/2-compositing/module3-2-script.sh
sh ./theme-park-backend/3-photos/3-postprocess/module3-3-script.sh
