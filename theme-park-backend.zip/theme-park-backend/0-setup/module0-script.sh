############ Module 0-Setup
cd ~/environment/
git clone https://github.com/aws-samples/aws-serverless-workshop-innovator-island ./theme-park-backend
sudo yum install jq -y
